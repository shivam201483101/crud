

<template>
  <div id="app">
    <Books />
  </div>
</template>

<script>
import Books from './components/BookList.vue';

export default {
  name: 'App',
  components: {
    Books
  }
};
</script>./components/BookList.vue
