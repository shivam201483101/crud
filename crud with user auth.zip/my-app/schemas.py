from typing import List, Optional, Generic, TypeVar
from pydantic import BaseModel, Field, EmailStr
from pydantic.generics import GenericModel

T = TypeVar('T')

# Book schemas
class BookSchema(BaseModel):
    id: Optional[int] = None
    title: str
    desc: Optional[str] = None

    class Config:
        orm_mode = True

class RequestBook(BaseModel):
    parameter: BookSchema = Field(...)

class Response(GenericModel, Generic[T]):
    code: int
    status: str
    message: str
    result: Optional[T]

class BookResponse(BaseModel):
    id: int
    title: str
    desc: str

    class Config:
        orm_mode = True

# User schemas
class UserBase(BaseModel):
    user_firstname: str
    user_lastname: str
    email_id: EmailStr

class UserCreate(BaseModel):
    email_id: str
    password: str
    user_firstname: Optional[str] = None
    user_lastname: Optional[str] = None


class UserSchema(BaseModel):
    user_id: Optional[int] = None
    user_firstname: str
    user_lastname: str
    email_id: EmailStr
    password:str

    class Config:
        orm_mode = True

class Token(BaseModel):
    access_token: str
    token_type: str

class TokenData(BaseModel):
    email_id: Optional[str] = None


class UserUpdate(BaseModel):
    user_firstname: Optional[str] = None
    user_lastname: Optional[str] = None
    email_id: Optional[str] = None
    password: Optional[str] = None

    class Config:
        orm_mode = True

class PasswordUpdate(BaseModel):
    current_password: str
    new_password: str

    class Config:
        orm_mode = True
