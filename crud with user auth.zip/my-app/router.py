from fastapi import APIRouter, HTTPException, Depends, status
from sqlalchemy.orm import Session
from fastapi.security import OAuth2PasswordRequestForm
from schemas import BookResponse,UserBase, BookSchema, RequestBook, Response, UserSchema, Token,UserUpdate,PasswordUpdate
import crud
from config import Localsession
from auth import get_current_user
from auth import update_password
from typing import Annotated

router = APIRouter()

def get_db():
    db = Localsession()
    try:
        yield db
    finally:
        db.close()

db_dependency = Annotated[Session, Depends(get_db)]
current_user_dependency=Annotated[UserSchema,Depends(get_current_user)]

# User registration
@router.post("/register", response_model=UserSchema, status_code=status.HTTP_201_CREATED)
async def register(user: UserSchema, db: db_dependency):
    return crud.create_user(db=db, user=user)

# User login
@router.post("/token", response_model=Token)
async def login_for_access_token( db: db_dependency,form_data: OAuth2PasswordRequestForm = Depends()):
    return crud.login_user(db=db, form_data=form_data)



@router.get('/user')
async def get_user_details(db: db_dependency, current_user:UserSchema = Depends(get_current_user)):
    user = crud.get_user(db, user_id=current_user.user_id)
    if not user:
        raise HTTPException(status_code=404, detail="User not found")
    return Response(code=200, status="OK", message="User fetched successfully", result=user).dict(exclude_none=True)

@router.put('/updateuser')
async def update_user_details(user_update: UserUpdate, db: db_dependency, current_user: UserSchema = Depends(get_current_user)):
    updated_user = crud.update_user(db, user_id=current_user.user_id, user_update=user_update)
    return Response(code=200, status="OK", message="User updated successfully", result=updated_user).dict(exclude_none=True)

@router.put('/updatepassword')
async def update_user_password(password_update: PasswordUpdate, db: Session = Depends(get_db), current_user: int = Depends(get_current_user)):
    updated_user = update_password(db, user_id=current_user.user_id, password_update=password_update)
    return Response(code=200, status="OK", message="Password updated successfully", result=updated_user).dict(exclude_none=True)
# @router.get('/user',response_model=UserBase)
# async def get_user(db: db_dependency ,current_user:UserSchema=Depends(get_current_user)):
#     _users=crud.get_all_user(db,user_id=current_user.user_id,skip=0,limit=100)
#     return Response(code=200, status="OK", message="Success in fetching the all user details", result=_users).dict(exclude_none=True)

# Create a book
@router.post('/create', status_code=status.HTTP_201_CREATED)
async def create(request: RequestBook, db: db_dependency, current_user: current_user_dependency):
    _book = crud.create_book(db, book=request.parameter, user_id=current_user.user_id)
    return Response(code=200, status="OK", message="Book created successfully", result=_book).dict(exclude_none=True)

# Get book details
@router.get('/')
async def getbook_details(db: db_dependency, current_user: UserSchema = Depends(get_current_user)):
    _book = crud.get_books_by_user(db, user_id=current_user.user_id, skip=0, limit=100)
    return Response(code=200, status="OK", message="Success in fetching the book details", result=_book).dict(exclude_none=True)

# Get a book by ID
@router.get('/{id}')
async def get(id: int, db: db_dependency, current_user: UserSchema = Depends(get_current_user)):
    _book = crud.getbook_id(db, book_id=id)
    if _book and _book.owner_id == current_user.user_id:
        return Response(code=200, status="Ok", message="Successfully fetched the data by id", result=_book).dict(exclude_none=True)
    else:
        raise HTTPException(status_code=403, detail="Not authorized to view this book")

# Update a book
@router.post('/update', response_model=BookResponse, status_code=200)
async def update_book(request: RequestBook, db: db_dependency, current_user: UserSchema = Depends(get_current_user)):
    _book = crud.getbook_id(db, book_id=request.parameter.id)
    if _book and _book.owner_id == current_user.user_id:
        updated_book = crud.update_book(db, book_id=request.parameter.id, title=request.parameter.title, desc=request.parameter.desc)
        return updated_book
    else:
        raise HTTPException(status_code=403, detail="Not authorized to update this book")

# Delete a book
@router.delete('/{id}')
async def delete(id: int, db: db_dependency, current_user: UserSchema = Depends(get_current_user)):
    _book = crud.getbook_id(db, book_id=id)
    if _book and _book.owner_id == current_user.user_id:
        crud.remove_book(db, book_id=id)
        return Response(code=200, status="Ok", message="Successfully deleted", result=None).dict(exclude_none=True)
    else:
        raise HTTPException(status_code=403, detail="Not authorized to delete this book")
