from sqlalchemy.orm import Session
from model import Book,User
from schemas import  UserSchema, BookSchema,UserUpdate
from auth import get_password_hash, create_access_token, verify_password
from fastapi import HTTPException, status
from datetime import timedelta
from fastapi.security import OAuth2PasswordRequestForm


# User CRUD operations

def create_user(db: Session, user: UserSchema):
    db_user = db.query(User).filter(User.email_id == user.email_id).first()
    if db_user:
        raise HTTPException(status_code=400, detail="Email already registered")
    hashed_password = get_password_hash(user.password)
    db_user = User(
        user_firstname=user.user_firstname,
        user_lastname=user.user_lastname,
        email_id=user.email_id,
        password=hashed_password,
    )
    db.add(db_user)
    db.commit()
    db.refresh(db_user)
    return db_user

def authenticate_user(db: Session, email: str, password: str):
    user = db.query(User).filter(User.email_id == email).first()
    if not user:
        return None
    if not verify_password(password, user.password):
        return None
    return user

def login_user(db: Session, form_data: OAuth2PasswordRequestForm):
    user = authenticate_user(db, form_data.username, form_data.password)
    if not user:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Incorrect username or password",
            headers={"WWW-Authenticate": "Bearer"},
        )
    access_token_expires = timedelta(minutes=30)
    access_token = create_access_token(
        data={"sub": user.email_id}, expires_delta=access_token_expires
    )
    return {"access_token": access_token, "token_type": "bearer"}

def get_all_user(db:Session,skip:int=0,limit:int=100):
    return db.query(User).offset(skip).limit(limit).all()

def getbook(db:Session,skip:int=0,limit:int=100):
    return db.query(Book).offset(skip).limit(limit).all()

def get_books_by_user(db: Session, user_id: int, skip: int = 0, limit: int = 100):
    return db.query(Book).filter(Book.owner_id == user_id).offset(skip).limit(limit).all()


def getbook_id(db: Session, book_id: int):
    return db.query(Book).filter(Book.id==book_id).first()

def create_book(db:Session,book:BookSchema,user_id:int):
    _book=Book(title=book.title,desc=book.desc,owner_id=user_id)
    db.add(_book)
    db.commit()
    db.refresh(_book)
    return _book


def remove_book(db: Session, book_id: int):
    _book=getbook_id(db=db,book_id=book_id)
    db.delete(_book)
    db.commit()
    

def update_book(db: Session, book_id: int,title:str,desc:str):
     _book = getbook_id(db=db, book_id=book_id)
     if _book:
        _book.title = title
        _book.desc = desc
        db.commit()
        db.refresh(_book)
        return _book
     return None




def get_user(db: Session, user_id: int):
    return db.query(User).filter(User.user_id == user_id).first()

def update_user(db: Session, user_id: int, user_update: UserUpdate):
    user = db.query(User).filter(User.user_id == user_id).first()
    if user_update.user_firstname:
        user.user_firstname = user_update.user_firstname
    if user_update.user_lastname:
        user.user_lastname = user_update.user_lastname
    if user_update.email_id:
        user.email_id = user_update.email_id
    if user_update.password:
        user.password = user_update.password  # Remember to hash the password in production
    db.commit()
    db.refresh(user)
    return user

