import { createRouter, createWebHistory } from 'vue-router';
import BookList from '../components/BookList.vue';
import Register from '../components/RegisterPage.vue';
import Login from '../components/LoginPage.vue';
import UserProfile from '../components/UserProfile.vue';

const routes = [
  { path: '/', redirect: '/register' },
  { path: '/register', component: Register },
  { path: '/login', component: Login },
  { path: '/books', component: BookList },
  { path: '/profile', component: UserProfile }
];

const router = createRouter({
  history: createWebHistory(process.env.BASE_URL),
  routes,
});

export default router;
