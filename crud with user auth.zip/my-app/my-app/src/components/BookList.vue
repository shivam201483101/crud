<template>
    <div>
      <button @click="goToProfile">User Settings</button>
      <h1>Books</h1>
    
      <form @submit.prevent="createBook">
        <input v-model="newBook.title" placeholder="Title" style="padding:10px;" /><br>
        <input v-model="newBook.desc" placeholder="Description"
               style="padding:10px;margin-top:10px;margin-bottom:10px;" /><br>
        <button type="submit">Add Book</button>
      </form><br>
      <h1>All Book Details</h1>
      <table>
        <thead>
          <tr>
            <th>ID</th>
            <th>Title</th>
            <th>Description</th>
            <th>Edit</th>
            <th>Delete</th>
          </tr>
        </thead>
        <tbody>
          <tr v-for="book in books" :key="book.id">
            <td>{{ book.id }}</td>
            <td>{{ book.title }}</td>
            <td>{{ book.desc }}</td>
            <td><button @click="editBook(book.id)">Edit</button></td>
            <td><button @click="deleteBook(book.id)">Delete</button></td>
          </tr>
        </tbody>
      </table>
      <div v-if="editingBook">
        <h2>Edit Book</h2>
        <form @submit.prevent="updateBk">
          <input v-model="editingBook.title" placeholder="Title" />
          <input v-model="editingBook.desc" placeholder="Description" />
          <button type="submit">Update Book</button>
          <button type="button" @click="cancelEdit">Cancel</button>
        </form>
      </div>
      <div>
        <h2>Get Book by ID</h2>
        <form @submit.prevent="getBookById">
          <input v-model="bookId" placeholder="Book ID" />
          <button type="submit">Get Book</button>
        </form>
        <div v-if="bookById">
          <h2>Book Details:</h2>
          <p>Title : {{ bookById.title }} </p>
          <p> Description : {{ bookById.desc }}</p>
        </div>
      </div>
    </div>
  </template>
  <style>
  table {
      border-collapse: collapse;
      width: 100%;
  }
  
  th,
  td {
      border: 1px solid black;
      /* Set border for table cells */
      padding: 8px;
      text-align: left;
  }
  
  th {
      background-color: #f2f2f2;
      /* Background color for table header */
  }
  
  th,
  td {
      font-weight: bold;
      /* Make table cells bold */
  }
  </style>
  <script>
  import axios from 'axios';
  
  export default {
    name: 'BookManager',
    data() {
      return {
        books: [],
        newBook: {
          title: '',
          desc: ''
        },
        editingBook: null,
        bookId: '',
        bookById: null
      };
    },
    methods: {
      async fetchBooks() {
        try {
          const token = localStorage.getItem('token');
          const response = await axios.get('http://localhost:8000/book/', {
            headers: {
              Authorization: `Bearer ${token}`
            }
          });
          this.books = response.data.result;
        } catch (error) {
          console.error(error);
        }
      },
      async createBook() {
        try {
          const token = localStorage.getItem('token');
          const response = await axios.post('http://localhost:8000/book/create', {
            parameter: this.newBook
          }, {
            headers: {
              Authorization: `Bearer ${token}`
            }
          });
          this.books.push(response.data.result);
          this.newBook.title = '';
          this.newBook.desc = '';
        } catch (error) {
          console.error(error);
        }
      },
      async updateBk() {
        try {
          const token = localStorage.getItem('token');
          let res = await axios.post('http://localhost:8000/book/update', {
            parameter: this.editingBook
          }, {
            headers: {
              Authorization: `Bearer ${token}`
            }
          });
          if (res.status == 200) {
            const updatedBook = res.data;
            const index = this.books.findIndex(book => book.id === updatedBook.id);
            if (index !== -1) {
              this.books.splice(index, 1, updatedBook);
            }
            this.editingBook = null;
            await this.fetchBooks();
          }
        } catch (error) {
          console.log(error);
        }
      },
      async deleteBook(id) {
        try {
          const token = localStorage.getItem('token');
          await axios.delete(`http://localhost:8000/book/${id}`, {
            headers: {
              Authorization: `Bearer ${token}`
            }
          });
          this.books = this.books.filter(book => book.id !== id);
        } catch (error) {
          console.error(error);
        }
      },
      async getBookById() {
        try {
          const token = localStorage.getItem('token');
          const response = await axios.get(`http://localhost:8000/book/${this.bookId}`, {
            headers: {
              Authorization: `Bearer ${token}`
            }
          });
          this.bookById = response.data.result;
        } catch (error) {
          console.error(error);
        }
      },

editBook(id) {
            const book = this.books.find(book => book.id === id);
            this.editingBook = { ...book };
        },
        cancelEdit() {
            this.editingBook = null;
        },
        goToProfile() {
      this.$router.push('/profile');
    }
    },
    mounted() {
        this.fetchBooks();
    }
  }
  
  </script>