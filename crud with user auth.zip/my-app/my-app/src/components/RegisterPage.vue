<template>
    <div>
      <h2>Register</h2>
      <form @submit.prevent="register">
        <input v-model="user.user_firstname" placeholder="First Name" />
        <input v-model="user.user_lastname" placeholder="Last Name" />
        <input v-model="user.email_id" placeholder="Email" />
        <input type="password" v-model="user.password" placeholder="Password" />
        <button type="submit">Register</button>
      </form>
      <button @click="goToLogin">Already registered? Login</button>
      

    </div>
  </template>
  
  <script>
  import axios from 'axios';
  import { useRouter } from 'vue-router';
  
  export default {
    data() {
      return {
        user: {
          user_firstname: '',
          user_lastname: '',
          email_id: '',
          password: ''
        }
      };
    },
    setup() {
    const router = useRouter();

    const goToLogin = () => {
      router.push('/login');
    };

    return { goToLogin };
  },
    methods: {
      async register() {
        try {
          const response = await axios.post('http://localhost:8000/book/register', this.user);
          console.log(response.data);
          this.$router.push('/login');
        } catch (error) {
          console.error(error);
        }
      }
    }
  };
  </script>
  