<template>
    <div>
      <h1>User Profile</h1>
      <table>
        <tr>
          <td>First Name:</td>
          <td>{{ user.user_firstname }}</td>
          <td><button @click="editingField = 'user_firstname'">Edit</button></td>
        </tr>
        <tr v-if="editingField === 'user_firstname'">
          <td colspan="3">
            <input v-model="user.user_firstname" placeholder="First Name" />
            <button @click="saveField('user_firstname')">Save</button>
            <button @click="cancelEdit">Cancel</button>
          </td>
        </tr>
        <tr>
          <td>Last Name:</td>
          <td>{{ user.user_lastname }}</td>
          <td><button @click="editingField = 'user_lastname'">Edit</button></td>
        </tr>
        <tr v-if="editingField === 'user_lastname'">
          <td colspan="3">
            <input v-model="user.user_lastname" placeholder="Last Name" />
            <button @click="saveField('user_lastname')">Save</button>
            <button @click="cancelEdit">Cancel</button>
          </td>
        </tr>
        <tr>
          <td>Email:</td>
          <td>{{ user.email_id }}</td>
          <td><button @click="editingField = 'email_id'">Edit</button></td>
        </tr>
        <tr v-if="editingField === 'email_id'">
          <td colspan="3">
            <input v-model="user.email_id" placeholder="Email" />
            <button @click="saveField('email_id')">Save</button>
            <button @click="cancelEdit">Cancel</button>
          </td>
        </tr>
        <tr>
          <td>Password:</td>
          <td>********</td>
        <td><button @click="editField('password')">Edit</button></td>
      </tr>
      <tr v-if="editingField === 'password'">
        <td colspan="3">
          <input v-model="passwordUpdate.current_password" type="password" placeholder="Current Password" />
          <input v-model="passwordUpdate.new_password" type="password" placeholder="New Password" />
          <button @click="saveField('password')">Save</button>
          <button @click="cancelEdit">Cancel</button>
        </td>
        </tr>
      </table>
    </div>
  </template>
  
  <script>
  import axios from 'axios';
  
  export default {
    name: 'UserProfile',
    data() {
      return {
        user: {
          user_firstname: '',
          user_lastname: '',
          email_id: '',
          password: ''
        },
        passwordUpdate: {
        current_password: '',
        new_password: ''
      },
        editingField: null
      };
    },
    async mounted() {
      const token = localStorage.getItem('token');
      try {
        const response = await axios.get('http://localhost:8000/book/user', {
          headers: {
            Authorization: `Bearer ${token}`
          }
        });
        this.user = response.data.result;
      } catch (error) {
        console.error(error);
      }
    },
    methods: {
      editField(field) {
      this.editingField = field;
    },

      async saveField(field) {
      const token = localStorage.getItem('token');
      if (field === 'password') {
        try {
          const response = await axios.put('http://localhost:8000/book/updatepassword', this.passwordUpdate, {
            headers: {
              Authorization: `Bearer ${token}`
            }
          });
          console.log(response);
          alert('Password updated successfully');
        } catch (error) {
          console.error(error);
          alert('Failed to update password');
        }
      } else {
        try {
          const updatedUser = { ...this.user };
          const response = await axios.put('http://localhost:8000/book/updateuser', updatedUser, {
            headers: {
              Authorization: `Bearer ${token}`
            }
          });
          this.user = response.data.result;
          alert('User updated successfully');
        } catch (error) {
          console.error(error);
          alert('Failed to update user');
        }
      }
      this.editingField = null;
    },
    cancelEdit() {
      this.editingField = null;
    }
      // async saveField(field) {
      //   const token = localStorage.getItem('token');
      //   try {
      //     const updatedUser = { ...this.user };
      //     if (field === 'password' && !this.user.password) {
      //       alert('Password cannot be empty');
      //       return;
      //     }
      //     const response = await axios.put('http://localhost:8000/book/updateuser', updatedUser, {
      //       headers: {
      //         Authorization: `Bearer ${token}`
      //       }
      //     });
      //     this.user = response.data.result;
      //     this.editingField = null;
      //     alert('User updated successfully');
      //   } catch (error) {
      //     console.error(error);
      //   }
      // },
      // cancelEdit() {
      //   this.editingField = null;
      // }
    }
  };
  </script>
  