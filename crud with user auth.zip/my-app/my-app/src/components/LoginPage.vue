<template>
    <div>
      <h2>Login</h2>
      <form @submit.prevent="login">
        <input v-model="credentials.username" placeholder="Email" />
        <input type="password" v-model="credentials.password" placeholder="Password" />
        <button type="submit">Login</button>
      </form>
      <button @click="goToRegister">Not registered? Register</button>
    </div>
  </template>
  
  <script>
  import axios from 'axios';
  import { useRouter } from 'vue-router';
  export default {
    data() {
      return {
        credentials: {
          username: '',
          password: ''
        }
      };
    },
    setup() {
    const router = useRouter();

    const goToRegister = () => {
      router.push('/register');
    };

    return { goToRegister };
  },
    methods: {
      async login() {
        try {
          const response = await axios.post('http://localhost:8000/book/token', new URLSearchParams(this.credentials));
          console.log(response.data);
          localStorage.setItem('token', response.data.access_token);
          this.$router.push('/books');
        } catch (error) {
          console.error(error);
        }
      }
    }
  };
  </script>
  