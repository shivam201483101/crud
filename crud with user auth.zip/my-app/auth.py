from datetime import datetime, timedelta
from typing import Union
from jose import JWTError, jwt
from passlib.context import CryptContext
from sqlalchemy.orm import Session
from fastapi import Depends, HTTPException, status
from fastapi.security import OAuth2PasswordBearer, OAuth2PasswordRequestForm
from model import User
from schemas import TokenData,PasswordUpdate
from config import Localsession

def get_db():
    db = Localsession()
    try:
        yield db
    finally:
        db.close()

SECRET_KEY = "your_secret_key"
ALGORITHM = "HS256"
ACCESS_TOKEN_EXPIRE_MINUTES = 30

pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")

oauth2_scheme = OAuth2PasswordBearer(tokenUrl="token")

def verify_password(plain_password, hashed_password):
    return pwd_context.verify(plain_password, hashed_password)

def get_password_hash(password):
    return pwd_context.hash(password)

def authenticate_user(db: Session, email: str, password: str):
    user = db.query(User).filter(User.email_id == email).first()
    if user is None or not verify_password(password, user.password):
        return False
    return user

def create_access_token(data: dict, expires_delta: Union[timedelta, None] = None):
    to_encode = data.copy()
    if expires_delta:
        expire = datetime.utcnow() + expires_delta
    else:
        expire = datetime.utcnow() + timedelta(minutes=30)
    to_encode.update({"exp": expire})
    encoded_jwt = jwt.encode(to_encode, SECRET_KEY, algorithm=ALGORITHM)
    return encoded_jwt

async def get_current_user(token: str = Depends(oauth2_scheme), db: Session = Depends(get_db)):
    credentials_exception = HTTPException(
        status_code=status.HTTP_401_UNAUTHORIZED,
        detail="Could not validate credentials",
        headers={"WWW-Authenticate": "Bearer"},
    )
    try:
        payload = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
        email_id: str = payload.get("sub")
        if email_id is None:
            raise credentials_exception
        token_data = TokenData(email_id=email_id)
    except JWTError:
        raise credentials_exception
    user = db.query(User).filter(User.email_id == token_data.email_id).first()
    if user is None:
        raise credentials_exception
    return user

def update_password(db: Session, user_id: int, password_update: PasswordUpdate):
    user = db.query(User).filter(User.user_id == user_id).first()
    if not verify_password(password_update.current_password, user.password):
        raise HTTPException(status_code=400, detail="Current password is incorrect")
    user.password = get_password_hash(password_update.new_password)
    db.commit()
    db.refresh(user)
    return user
