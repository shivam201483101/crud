from sqlalchemy import Column,Integer,String,ForeignKey
from config import Base
from sqlalchemy.orm import relationship

class Book(Base):
    __tablename__='book'

    id=Column(Integer,primary_key=True,index=True)
    title=Column(String)
    desc=Column(String)
    owner_id = Column(Integer, ForeignKey('users.user_id'))
    owner=relationship("User",back_populates="books")      

class User(Base):
    __tablename__="users"
    user_id=Column(Integer,primary_key=True,index=True)
    user_firstname=Column(String)
    user_lastname=Column(String)
    email_id=Column(String,unique=True,index=True)
    password=Column(String)
    books = relationship("Book", back_populates="owner")
     