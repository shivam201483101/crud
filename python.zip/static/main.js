document.addEventListener('DOMContentLoaded', function() {
    const apiUrl = 'http://127.0.0.1:8000/items/';

    // Function to load all items
    function loadItems() {
        axios.get(apiUrl)
            .then(response => {
                const itemsTableBody = document.getElementById('items-table-body');
                itemsTableBody.innerHTML = '';
                const data = response.data;
                for (const id in data) {
                    const item = data[id];
                    itemsTableBody.innerHTML += `
                        <tr>
                            <td>${id}</td>
                            <td>${item.name}</td>
                            <td>${item.description}</td>
                            <td>${item.price}</td>
                            <td>
                                <button class="btn btn-danger delete-btn" data-id="${id}">Delete</button>
                            </td>
                        </tr>
                    `;
                }
            })
            .catch(error => console.error('Error loading items:', error));
    }

    // Load items on page load
    loadItems();

    // Handle form submission for creating a new item
    document.getElementById('create-item-form').addEventListener('submit', function(event) {
    
        event.preventDefault();
        const newItem = {
            name: document.getElementById('name').value,
            description: document.getElementById('description').value,
            price: document.getElementById('price').value
        };
        axios.post(apiUrl, newItem)
            .then(() => {
                loadItems();
                document.getElementById('create-item-form').reset();
            })
            .catch(error => console.error('Error creating item:', error));
    });

    // Handle form submission for updating an item
    document.getElementById('update-item-form').addEventListener('submit', function(event) {
        event.preventDefault();
        const updateItem = {
            name: document.getElementById('update-name').value,
            description: document.getElementById('update-description').value,
            price: document.getElementById('update-price').value
        };
        const itemId = document.getElementById('update-id').value;
        axios.put(`${apiUrl}${itemId}`, updateItem)
            .then(() => {
                loadItems();
                document.getElementById('update-item-form').reset();
            })
            .catch(error => console.error('Error updating item:', error));
    });

    // Handle item deletion
    document.getElementById('items-table-body').addEventListener('click', function(event) {
        if (event.target.classList.contains('delete-btn')) {
            const itemId = event.target.getAttribute('data-id');
            axios.delete(`${apiUrl}${itemId}`)
                .then(() => loadItems())
                .catch(error => console.error('Error deleting item:', error));
        }
    });
});
