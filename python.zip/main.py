from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from typing import Dict
from fastapi.staticfiles import StaticFiles
from fastapi.middleware.cors import CORSMiddleware

app = FastAPI()

app.mount("/static", StaticFiles(directory="static"), name="static")


# Add CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Allow all origins
    allow_credentials=True,
    allow_methods=["*"],  # Allow all methods
    allow_headers=["*"],  # Allow all headers
)

# In-memory dictionary to store the data
data_store: Dict[int, Dict] = {}

# Pydantic model for the items


class Item(BaseModel):
    name: str
    description: str
    price: float


@app.get("/")
def read_root():
    return {"message": "Welcome to the FastAPI CRUD example!"}


@app.post("/items/", response_model=Dict[int, Dict])
def create_item(item: Item):
    item_id = len(data_store) + 1  # Generate a new ID
    data_store[item_id] = item.dict()
    return {item_id: data_store[item_id]}


@app.get("/items/{item_id}", response_model=Dict)
def read_item(item_id: int):
    if item_id in data_store:
        return data_store[item_id]
    raise HTTPException(status_code=404, detail="Item not found")


@app.put("/items/{item_id}", response_model=Dict)
def update_item(item_id: int, item: Item):
    if item_id in data_store:
        data_store[item_id] = item.dict()
        return data_store[item_id]
    raise HTTPException(status_code=404, detail="Item not found")


@app.delete("/items/{item_id}", response_model=Dict)
def delete_item(item_id: int):
    if item_id in data_store:
        deleted_item = data_store.pop(item_id)
        return deleted_item
    raise HTTPException(status_code=404, detail="Item not found")
