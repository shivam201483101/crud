from sqlalchemy.orm import Session
from model import Book
from schemas import BookSchema

def getbook(db:Session,skip:int=0,limit:int=100):
    return db.query(Book).offset(skip).limit(limit).all()


def getbook_id(db: Session, book_id: int):
    return db.query(Book).filter(Book.id==book_id).first()

def create_book(db:Session,book:BookSchema):
    _book=Book(title=book.title,desc=book.desc)
    db.add(_book)
    db.commit()
    db.refresh(_book)
    return _book


def remove_book(db: Session, book_id: int):
    _book=getbook_id(db=db,book_id=book_id)
    db.delete(_book)
    db.commit()
    

def update_book(db: Session, book_id: int,title:str,desc:str):
     _book = getbook_id(db=db, book_id=book_id)
     if _book:
        _book.title = title
        _book.desc = desc
        db.commit()
        db.refresh(_book)
        return _book
     return None

