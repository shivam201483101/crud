from fastapi import APIRouter,HTTPException,Path,Depends
from config import Localsession
from sqlalchemy.orm import Session
from schemas import BookResponse, BookSchema,RequestBook,Response
import crud


router=APIRouter()

def get_db():
    db=Localsession()
    try:
         yield db

    finally:
        db.close()

@router.post('/create')
async def create(request:RequestBook,db:Session=Depends(get_db)):
    _book=crud.create_book(db,book=request.parameter)
    return Response(code=200,status="OK",message="Book created successfully",result=_book).dict(exclude_none=True)


@router.get('/')
async def getbook_details(db:Session=Depends(get_db)):
    _book=crud.getbook(db,0,100)
    return Response(code=200, status="OK",message="Success in fetching the book details",result=_book).dict(exclude_none=True)

@router.get('/{id}')
async def get(id:int,db:Session=Depends(get_db)):
    _book=crud.getbook_id(db,id)
    return Response(code=200,status="Ok",message="successfully fetching the data by id",result=_book).dict(exclude_none=True)


@router.post('/update', response_model=BookResponse,status_code=200)
async def update_book(request:RequestBook, db: Session = Depends(get_db)):
    _book = crud.update_book(db, book_id=request.parameter.id,
                             title=request.parameter.title, desc=request.parameter.desc)
    return _book
@router.delete('/{id}')
async def delete(id:int,db:Session=Depends(get_db)):
    crud.remove_book(db,book_id=id)
    return Response(code=200, status="Ok", message="successfully deleted ",result=None).dict(exclude_none=True)
